/****************************************************************************
** Meta object code from reading C++ file 'validator.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../../validator.h"
#include <QtNetwork/QSslError>
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'validator.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSValidatorENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSValidatorENDCLASS = QtMocHelpers::stringData(
    "Validator",
    "requestLocalhost",
    "",
    "requestIpAddress",
    "ip",
    "requestUrl",
    "url",
    "debugMessage",
    "message",
    "validationResult",
    "success",
    "resolvedValue",
    "databaseError",
    "error",
    "requestFinished",
    "apiResponseReceived",
    "hostname",
    "city",
    "region",
    "country",
    "loc",
    "postal",
    "timezone",
    "handleApiResponse",
    "validateInput",
    "input",
    "retrieveData",
    "clearDatabase",
    "copyToClipboard",
    "text"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSValidatorENDCLASS_t {
    uint offsetsAndSizes[60];
    char stringdata0[10];
    char stringdata1[17];
    char stringdata2[1];
    char stringdata3[17];
    char stringdata4[3];
    char stringdata5[11];
    char stringdata6[4];
    char stringdata7[13];
    char stringdata8[8];
    char stringdata9[17];
    char stringdata10[8];
    char stringdata11[14];
    char stringdata12[14];
    char stringdata13[6];
    char stringdata14[16];
    char stringdata15[20];
    char stringdata16[9];
    char stringdata17[5];
    char stringdata18[7];
    char stringdata19[8];
    char stringdata20[4];
    char stringdata21[7];
    char stringdata22[9];
    char stringdata23[18];
    char stringdata24[14];
    char stringdata25[6];
    char stringdata26[13];
    char stringdata27[14];
    char stringdata28[16];
    char stringdata29[5];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSValidatorENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSValidatorENDCLASS_t qt_meta_stringdata_CLASSValidatorENDCLASS = {
    {
        QT_MOC_LITERAL(0, 9),  // "Validator"
        QT_MOC_LITERAL(10, 16),  // "requestLocalhost"
        QT_MOC_LITERAL(27, 0),  // ""
        QT_MOC_LITERAL(28, 16),  // "requestIpAddress"
        QT_MOC_LITERAL(45, 2),  // "ip"
        QT_MOC_LITERAL(48, 10),  // "requestUrl"
        QT_MOC_LITERAL(59, 3),  // "url"
        QT_MOC_LITERAL(63, 12),  // "debugMessage"
        QT_MOC_LITERAL(76, 7),  // "message"
        QT_MOC_LITERAL(84, 16),  // "validationResult"
        QT_MOC_LITERAL(101, 7),  // "success"
        QT_MOC_LITERAL(109, 13),  // "resolvedValue"
        QT_MOC_LITERAL(123, 13),  // "databaseError"
        QT_MOC_LITERAL(137, 5),  // "error"
        QT_MOC_LITERAL(143, 15),  // "requestFinished"
        QT_MOC_LITERAL(159, 19),  // "apiResponseReceived"
        QT_MOC_LITERAL(179, 8),  // "hostname"
        QT_MOC_LITERAL(188, 4),  // "city"
        QT_MOC_LITERAL(193, 6),  // "region"
        QT_MOC_LITERAL(200, 7),  // "country"
        QT_MOC_LITERAL(208, 3),  // "loc"
        QT_MOC_LITERAL(212, 6),  // "postal"
        QT_MOC_LITERAL(219, 8),  // "timezone"
        QT_MOC_LITERAL(228, 17),  // "handleApiResponse"
        QT_MOC_LITERAL(246, 13),  // "validateInput"
        QT_MOC_LITERAL(260, 5),  // "input"
        QT_MOC_LITERAL(266, 12),  // "retrieveData"
        QT_MOC_LITERAL(279, 13),  // "clearDatabase"
        QT_MOC_LITERAL(293, 15),  // "copyToClipboard"
        QT_MOC_LITERAL(309, 4)   // "text"
    },
    "Validator",
    "requestLocalhost",
    "",
    "requestIpAddress",
    "ip",
    "requestUrl",
    "url",
    "debugMessage",
    "message",
    "validationResult",
    "success",
    "resolvedValue",
    "databaseError",
    "error",
    "requestFinished",
    "apiResponseReceived",
    "hostname",
    "city",
    "region",
    "country",
    "loc",
    "postal",
    "timezone",
    "handleApiResponse",
    "validateInput",
    "input",
    "retrieveData",
    "clearDatabase",
    "copyToClipboard",
    "text"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSValidatorENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
      13,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       8,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,   92,    2, 0x06,    1 /* Public */,
       3,    1,   93,    2, 0x06,    2 /* Public */,
       5,    1,   96,    2, 0x06,    4 /* Public */,
       7,    1,   99,    2, 0x06,    6 /* Public */,
       9,    3,  102,    2, 0x06,    8 /* Public */,
      12,    1,  109,    2, 0x06,   12 /* Public */,
      14,    0,  112,    2, 0x06,   14 /* Public */,
      15,    8,  113,    2, 0x06,   15 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
      23,    8,  130,    2, 0x08,   24 /* Private */,

 // methods: name, argc, parameters, tag, flags, initial metatype offsets
      24,    1,  147,    2, 0x02,   33 /* Public */,
      26,    0,  150,    2, 0x02,   35 /* Public */,
      27,    0,  151,    2, 0x02,   36 /* Public */,
      28,    1,  152,    2, 0x02,   37 /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    4,
    QMetaType::Void, QMetaType::QString,    6,
    QMetaType::Void, QMetaType::QString,    8,
    QMetaType::Void, QMetaType::Bool, QMetaType::QString, QMetaType::QString,   10,    8,   11,
    QMetaType::Void, QMetaType::QString,   13,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString,    4,   16,   17,   18,   19,   20,   21,   22,

 // slots: parameters
    QMetaType::Void, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString,    4,   16,   17,   18,   19,   20,   21,   22,

 // methods: parameters
    QMetaType::Void, QMetaType::QString,   25,
    QMetaType::QStringList,
    QMetaType::Bool,
    QMetaType::Void, QMetaType::QString,   29,

       0        // eod
};

Q_CONSTINIT const QMetaObject Validator::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_CLASSValidatorENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSValidatorENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSValidatorENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<Validator, std::true_type>,
        // method 'requestLocalhost'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'requestIpAddress'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'requestUrl'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'debugMessage'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'validationResult'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'databaseError'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'requestFinished'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'apiResponseReceived'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'handleApiResponse'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'validateInput'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'retrieveData'
        QtPrivate::TypeAndForceComplete<QList<QString>, std::false_type>,
        // method 'clearDatabase'
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'copyToClipboard'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>
    >,
    nullptr
} };

void Validator::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<Validator *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->requestLocalhost(); break;
        case 1: _t->requestIpAddress((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 2: _t->requestUrl((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 3: _t->debugMessage((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 4: _t->validationResult((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[3]))); break;
        case 5: _t->databaseError((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 6: _t->requestFinished(); break;
        case 7: _t->apiResponseReceived((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[4])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[5])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[6])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[7])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[8]))); break;
        case 8: _t->handleApiResponse((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[4])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[5])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[6])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[7])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[8]))); break;
        case 9: _t->validateInput((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 10: { QList<QString> _r = _t->retrieveData();
            if (_a[0]) *reinterpret_cast< QList<QString>*>(_a[0]) = std::move(_r); }  break;
        case 11: { bool _r = _t->clearDatabase();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 12: _t->copyToClipboard((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (Validator::*)();
            if (_t _q_method = &Validator::requestLocalhost; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (Validator::*)(const QString & );
            if (_t _q_method = &Validator::requestIpAddress; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (Validator::*)(const QString & );
            if (_t _q_method = &Validator::requestUrl; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (Validator::*)(const QString & );
            if (_t _q_method = &Validator::debugMessage; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (Validator::*)(bool , const QString & , const QString & );
            if (_t _q_method = &Validator::validationResult; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (Validator::*)(const QString & );
            if (_t _q_method = &Validator::databaseError; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (Validator::*)();
            if (_t _q_method = &Validator::requestFinished; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 6;
                return;
            }
        }
        {
            using _t = void (Validator::*)(const QString & , const QString & , const QString & , const QString & , const QString & , const QString & , const QString & , const QString & );
            if (_t _q_method = &Validator::apiResponseReceived; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 7;
                return;
            }
        }
    }
}

const QMetaObject *Validator::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Validator::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSValidatorENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int Validator::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 13)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 13;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 13)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 13;
    }
    return _id;
}

// SIGNAL 0
void Validator::requestLocalhost()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void Validator::requestIpAddress(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void Validator::requestUrl(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void Validator::debugMessage(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void Validator::validationResult(bool _t1, const QString & _t2, const QString & _t3)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void Validator::databaseError(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void Validator::requestFinished()
{
    QMetaObject::activate(this, &staticMetaObject, 6, nullptr);
}

// SIGNAL 7
void Validator::apiResponseReceived(const QString & _t1, const QString & _t2, const QString & _t3, const QString & _t4, const QString & _t5, const QString & _t6, const QString & _t7, const QString & _t8)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t4))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t5))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t6))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t7))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t8))) };
    QMetaObject::activate(this, &staticMetaObject, 7, _a);
}
QT_WARNING_POP
